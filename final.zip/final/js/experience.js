const experience = [
  {
    title: "Principal Application Support Engineer",
    company: "Proxy Live Solutions, Riga (Latvia)",
    period: "August 2022 - Present",
  },
  {
    title: "Application Support Engineer",
    company: "Proxy Live Solutions, Riga (Latvia)",
    period: "November 2022 - August 2022",
  },
  {
    title: "Project Manager",
    company: 'SIA "LSK", Riga (Latvia)',
    period: "September 2021 - November 2022",
  },
  {
    title: "Service Manager",
    company: 'SIA "LSK", Riga (Latvia)',
    period: "December 2020 - September 2021",
  },
];
